from .rust_compressor import *

__doc__ = rust_compressor.__doc__
if hasattr(rust_compressor, "__all__"):
    __all__ = rust_compressor.__all__