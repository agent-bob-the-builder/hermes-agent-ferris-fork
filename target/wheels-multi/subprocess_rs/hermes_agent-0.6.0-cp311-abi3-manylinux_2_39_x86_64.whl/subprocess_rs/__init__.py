from .subprocess_rs import *

__doc__ = subprocess_rs.__doc__
if hasattr(subprocess_rs, "__all__"):
    __all__ = subprocess_rs.__all__