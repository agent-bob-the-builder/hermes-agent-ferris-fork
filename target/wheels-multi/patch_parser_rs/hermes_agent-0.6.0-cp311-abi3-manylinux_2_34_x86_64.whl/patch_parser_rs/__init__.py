from .patch_parser_rs import *

__doc__ = patch_parser_rs.__doc__
if hasattr(patch_parser_rs, "__all__"):
    __all__ = patch_parser_rs.__all__