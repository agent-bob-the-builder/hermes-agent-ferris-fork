from .compressor_rs import *

__doc__ = compressor_rs.__doc__
if hasattr(compressor_rs, "__all__"):
    __all__ = compressor_rs.__all__